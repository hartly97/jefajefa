// // // app/javascript/controllers/source_picker_controller.js
 import { Controller } from "@hotwired/stimulus"

// // export default class extends Controller {
// //   static targets = ["query", "results"]

// //   pick(event) {
// //     const id = event.target.value
// //     if (!id) return
// //     this._setSelected(id, event.target.options[event.target.selectedIndex]?.textContent || `Source #${id}`)
// //     // clear recent select
// //     event.target.selectedIndex = 0
// //   }

// //   autocomplete() {
// //     const q = this.queryTarget.value.trim()
// //     clearTimeout(this._t)
// //     if (q.length < 2) { this.resultsTarget.innerHTML = ""; return }
// //     this._t = setTimeout(async () => {
// //       const res = await fetch(`/sources/autocomplete?q=${encodeURIComponent(q)}`)
// //       const items = await res.json()
// //       this.resultsTarget.innerHTML = items.map(i =>
// //         `<li class="list-group-item" data-id="${i.id}" data-title="${this._escape(i.title)}">${this._escape(i.title)}</li>`
// //       ).join("")
// //       this.resultsTarget.querySelectorAll("li").forEach(li => {
// //         li.addEventListener("click", () => {
// //           this._setSelected(li.dataset.id, li.dataset.title)
// //           this.resultsTarget.innerHTML = ""
// //           this.queryTarget.value = li.dataset.title
// //         })
// //       })
// //     }, 200)
// //   }

// //   _setSelected(id, title) {
// //     // Find the sibling collection_select for this citation block
// //     const wrapper = this.element.closest("[data-citations-wrapper]") || document
// //     const select  = wrapper.querySelector('[id^="citation_source_id_"]')
// //     if (!select) return
// //     // Replace options with the selected one so Rails submits correct source_id
// //     select.innerHTML = `<option value="${id}" selected>${this._escape(title)}</option>`
// //   }

// //   _escape(s) {
// //     return (s || "").replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))
// //   }
// // }

// // // app/javascript/controllers/source_picker_controller.js
// // import { Controller } from "@hotwired/stimulus"

// // export default class extends Controller {
// //   static targets = ["query", "results", "select"]

// //   pick(event) {
// //     const id = event.target.value
// //     if (!id) return
// //     const title = event.target.options[event.target.selectedIndex]?.textContent || `Source #${id}`
// //     this._setSelected(id, title)
// //     event.target.selectedIndex = 0 // clear "recent" select if you use one
// //   }

// //   autocomplete() {
// //     const q = this.queryTarget.value.trim()
// //     clearTimeout(this._t)
// //     if (q.length < 2) { this.resultsTarget.innerHTML = ""; return }
// //     this._t = setTimeout(async () => {
// //       const res = await fetch(`/sources/autocomplete?q=${encodeURIComponent(q)}`)
// //       const items = await res.json()
// //       this.resultsTarget.innerHTML = items.map(i =>
// //         `<li class="list-group-item" data-id="${i.id}" data-title="${this._escape(i.title)}">${this._escape(i.title)}</li>`
// //       ).join("")
// //       this.resultsTarget.querySelectorAll("li").forEach(li => {
// //         li.addEventListener("click", () => {
// //           this._setSelected(li.dataset.id, li.dataset.title)
// //           this.resultsTarget.innerHTML = ""
// //           this.queryTarget.value = li.dataset.title
// //         })
// //       })
// //     }, 200)
// //   }

// //   _setSelected(id, title) {
// //     if (!this.hasSelectTarget) return
// //     // Replace with the selected one so Rails submits the correct source_id
// //     this.selectTarget.innerHTML = `<option value="${id}" selected>${this._escape(title)}</option>`
// //   }

// //   _escape(s) {
// //     return (s || "").replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))
// //   }
// // }

// // app/javascript/controllers/source_picker_controller.js
// import { Controller } from "@hotwired/stimulus"

// // Works with citations/_fields.html.erb targets:
// // data-source-picker-target="select", "query", "results", optional "newForm"
// export default class extends Controller {
//   static targets = ["select", "query", "results", "newForm"]

//   // User clicked a "recent" select or a search result invokes this via data-action
//   pick(event) {
//     const el = event?.target
//     const id = el?.value
//     if (!id) return
//     const title = el.options?.[el.selectedIndex]?.textContent?.trim() || `Source #${id}`
//     this._setSelected(id, title)
//     // Reset the "recent" dropdown back to placeholder if present
//     if (el && typeof el.selectedIndex === "number") el.selectedIndex = 0
//     this._clearInlineSourceForm()
//     this._hideNewForm()
//   }

//   // Autocomplete against /sources/autocomplete?q=...
//   autocomplete() {
//     if (!this.hasQueryTarget) return
//     const q = this.queryTarget.value.trim()
//     clearTimeout(this._t)
//     if (q.length < 2) { this._clearResults(); return }
//     this._t = setTimeout(async () => {
//       try {
//         const res = await fetch(`/sources/autocomplete?q=${encodeURIComponent(q)}`)
//         if (!res.ok) throw new Error(`HTTP ${res.status}`)
//         const items = await res.json()
//         this._renderResults(items)
//       } catch (err) {
//         console.error("[source-picker] autocomplete error:", err)
//         this._clearResults()
//       }
//     }, 200)
//   }

//   // If typing a new Source title, clear any selected source_id
//   clearSelectIfTyped() {
//     if (this.hasSelectTarget && this.selectTarget.value) {
//       this.selectTarget.innerHTML = '<option value=""></option>'
//     }
//   }

//   toggleNewForm() {
//     if (!this.hasNewFormTarget) return
//     const s = this.newFormTarget.style
//     s.display = (s.display === "none" || !s.display) ? "block" : "none"
//     if (s.display === "block") this._clearSelectionOnly()
//   }

//   // ----- private helpers -----

//   _renderResults(items) {
//     if (!this.hasResultsTarget) return
//     this.resultsTarget.innerHTML = (items || []).map(i =>
//       `<li class="list-group-item" data-id="${this._esc(i.id)}" data-title="${this._esc(i.title)}">${this._esc(i.title)}</li>`
//     ).join("")
//     this.resultsTarget.querySelectorAll("li").forEach(li => {
//       li.addEventListener("click", () => {
//         this._setSelected(li.dataset.id, li.dataset.title)
//         this._clearResults()
//         if (this.hasQueryTarget) this.queryTarget.value = li.dataset.title
//         this._clearInlineSourceForm()
//         this._hideNewForm()
//       })
//     })
//   }

//   _clearResults() {
//     if (this.hasResultsTarget) this.resultsTarget.innerHTML = ""
//   }

//   _setSelected(id, title) {
//     if (!this.hasSelectTarget) return
//     const safeTitle = this._esc(title)
//     this.selectTarget.innerHTML = `<option value="${this._esc(id)}" selected>${safeTitle}</option>`
//     // Fire a change event in case anything else listens
//     const ev = new Event("change", { bubbles: true })
//     this.selectTarget.dispatchEvent(ev)
//   }

//   _clearSelectionOnly() {
//     if (this.hasSelectTarget) this.selectTarget.innerHTML = '<option value=""></option>'
//     this._clearResults()
//     if (this.hasQueryTarget) this.queryTarget.value = ""
//   }

//   _clearInlineSourceForm() {
//     // Blank any nested source_attributes fields within this citation wrapper
//     const wrapper = this.element.closest("[data-citations-wrapper]") || this.element
//     const inputs = wrapper.querySelectorAll('[name*="[source_attributes]"]')
//     inputs.forEach(inp => {
//       if (inp.tagName === "TEXTAREA") inp.value = ""
//       else if (inp.type === "checkbox" || inp.type === "radio") inp.checked = false
//       else inp.value = ""
//     })
//   }

//   _hideNewForm() {
//     if (!this.hasNewFormTarget) return
//     const s = this.newFormTarget.style
//     if (s.display !== "none") s.display = "none"
//   }

//   _esc(s) {
//     return String(s ?? "").replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',\"'\":'&#39;'}[c]))
//   }
// }

 import { Controller } from "@hotwired/stimulus"
<%# app/views/citations/_fields.html.erb %>
<%# Locals expected: f: (form builder for Citation), sources: a collection of Source records %>


<div class="border p-3 mb-3 rounded citation-fields"
     data-controller="source-picker"
     data-citations-wrapper>

  <div class="d-flex justify-content-between align-items-center mb-2">
    <strong>Citation</strong>
    <button type="button" class="btn btn-sm btn-outline-danger" data-action="citations#remove">Remove</button>
  </div>

  <!-- Pick existing source -->
  <div class="field mb-2">
    <%= f.label :source_id, "Source" %>
    <%= f.collection_select :source_id,
          (defined?(sources) && sources.present?) ? sources : Source.order(:title),
          :id, :title,
          { include_blank: "— Select a source —" },
          { class: "form-select", data: { "source-picker-target": "select" } } %>
    <small class="text-muted">
      Tip: pass @sources to show all; or pass Source.common if you maintain a curated list.
    </small>
  </div>

  <!-- Autocomplete search -->
  <div class="mb-2">
    <label>Search all sources</label>
    <input type="text"
           class="form-control"
           placeholder="Type 2+ letters…"
           data-action="input->source-picker#autocomplete"
           data-source-picker-target="query">
    <ul class="list-group mt-1" data-source-picker-target="results"></ul>
  </div>

  <!-- Recent quick-pick (optional) -->
  <div class="mb-2">
    <label>Recent</label>
    <%= select_tag :recent_source_id,
          options_from_collection_for_select(Source.order(updated_at: :desc).limit(10), :id, :title),
          include_blank: "— Pick recent —",
          class: "form-select",
          data: { action: "source-picker#pick" } %>
  </div>

  <!-- OR: create a new source inline -->
  <div class="mt-3">
    <button class="btn btn-sm btn-outline-secondary"
            type="button"
            data-action="click->source-picker#toggleNewForm">
      + Add a new source instead
    </button>

    <div class="mt-2" data-source-picker-target="newForm" style="display:none">
      <div class="alert alert-info py-2 px-3 mb-2">
        Leave “Source” above blank if you enter a new one here.
      </div>

      <%= f.fields_for :source do |sf| %>
        <div class="row g-3">
          <div class="col-md-8">
            <%= sf.label :title %>
            <%= sf.text_field :title, class: "form-control",
                  placeholder: "Book/Newspaper/Collection title",
                  data: { action: "input->source-picker#clearSelectIfTyped" } %>
          </div>
          <div class="col-md-4">
            <%= sf.label :author %>
            <%= sf.text_field :author, class: "form-control" %>
          </div>

          <div class="col-md-3">
            <%= sf.label :publisher %>
            <%= sf.text_field :publisher, class: "form-control" %>
          </div>
          <div class="col-md-2">
            <%= sf.label :year %>
            <%= sf.text_field :year, class: "form-control" %>
          </div>
          <div class="col-md-7">
            <%= sf.label :url, "URL" %>
            <%= sf.url_field :url, class: "form-control" %>
          </div>

          <div class="col-md-6">
            <%= sf.label :repository %>
            <%= sf.text_field :repository, class: "form-control" %>
          </div>
          <div class="col-md-6">
            <%= sf.label :link_url, "Repository link" %>
            <%= sf.url_field :link_url, class: "form-control" %>
          </div>

          <div class="col-12">
            <%= sf.label :details %>
            <%= sf.text_area :details, rows: 2, class: "form-control" %>
          </div>
        </div>
      <% end %>
    </div>
  </div>

  <!-- Locator fields -->
  <div class="row g-3 mt-3">
    <div class="col-md-6">
      <%= f.label :page, "Page" %>
      <%= f.text_field :page, class: "form-control", placeholder: "e.g., 12–13" %>
    </div>
    <div class="col-md-6">
      <%= f.label :folio %>
      <%= f.text_field :folio, class: "form-control" %>
    </div>
    <div class="col-md-6">
      <%= f.label :column %>
      <%= f.text_field :column, class: "form-control" %>
    </div>
    <div class="col-md-6">
      <%= f.label :line_number, "Line #" %>
      <%= f.text_field :line_number, class: "form-control" %>
    </div>
    <div class="col-md-6">
      <%= f.label :record_number %>
      <%= f.text_field :record_number, class: "form-control" %>
    </div>
    <div class="col-md-6">
      <%= f.label :locator, "Other locator" %>
      <%= f.text_field :locator, class: "form-control" %>
    </div>
    <div class="col-md-6">
      <%= f.label :image_url, "Image URL" %>
      <%= f.url_field :image_url, class: "form-control" %>
    </div>
    <div class="col-md-3">
      <%= f.label :image_frame, "Frame" %>
      <%= f.text_field :image_frame, class: "form-control" %>
    </div>
    <div class="col-md-3">
      <%= f.label :roll, "Roll / Piece" %>
      <%= f.text_field :roll, class: "form-control" %>
    </div>
    <div class="col-md-6">
      <%= f.label :enumeration_district, "ED" %>
      <%= f.text_field :enumeration_district, class: "form-control" %>
    </div>
  </div>

  <div class="mt-3">
    <%= f.label :quote %>
    <%= f.text_area :quote, rows: 2, class: "form-control" %>
  </div>
  <div class="mt-2">
    <%= f.label :note %>
    <%= f.text_area :note, rows: 2, class: "form-control" %>
  </div>

  <%= f.check_box :_destroy, style: "display:none" %>
</div>


// app/javascript/controllers/source_picker_controller.js
import { Controller } from "@hotwired/stimulus"

export default class extends Controller {
  static targets = ["query", "results", "select"]

  pick(event) {
    const id = event.target.value
    if (!id) return
    const title = event.target.options[event.target.selectedIndex]?.textContent || `Source #${id}`
    this._setSelected(id, title)
    event.target.selectedIndex = 0 // clear "recent" select if you use one
  }

  autocomplete() {
    const q = this.queryTarget.value.trim()
    clearTimeout(this._t)
    if (q.length < 2) { this.resultsTarget.innerHTML = ""; return }
    this._t = setTimeout(async () => {
      const res = await fetch(`/sources/autocomplete?q=${encodeURIComponent(q)}`)
      const items = await res.json()
      this.resultsTarget.innerHTML = items.map(i =>
        `<li class="list-group-item" data-id="${i.id}" data-title="${this._escape(i.title)}">${this._escape(i.title)}</li>`
      ).join("")
      this.resultsTarget.querySelectorAll("li").forEach(li => {
        li.addEventListener("click", () => {
          this._setSelected(li.dataset.id, li.dataset.title)
          this.resultsTarget.innerHTML = ""
          this.queryTarget.value = li.dataset.title
        })
      })
    }, 200)
  }

  _setSelected(id, title) {
    if (!this.hasSelectTarget) return
    // Replace with the selected one so Rails submits the correct source_id
    this.selectTarget.innerHTML = `<option value="${id}" selected>${this._escape(title)}</option>`
  }

  _escape(s) {
    return (s || "").replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))
  }
}
