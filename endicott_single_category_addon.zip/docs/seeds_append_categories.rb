# Append to db/seeds.rb (single-category flavor)
puts "Seeding categories..."
%w[Military Genealogy Newspaper Census].each { |n| Category.where(name: n).first_or_create! }

if defined?(Source) && Source.column_names.include?("category_id")
  if (s = Source.first) && s.category.nil?
    s.update!(category: Category.find_by(name: "Genealogy"))
  end
end

if defined?(Census) && Census.column_names.include?("category_id")
  if (c = Census.first) && c.category.nil?
    c.update!(category: Category.find_by(name: "Census"))
  end
end
puts "Categories seeded/assigned."
