# Single Category Add-on (no tags)

This add-on switches to a **one-to-many** category model (each record has *one* category).
No join table is required; it uses a `category_id` FK on your models.

## Files
- `app/models/category.rb` — simple Category model (optional Sluggable)
- `db/migrate/*_add_category_refs_to_models.rb` — adds `category_id` to common tables, guarded
- `app/views/shared/_category_field.html.erb` — form select for one category
- `app/views/shared/_category_badge.html.erb` — tiny display helper
- `docs/patches/censuses_form_add_category.diff` — drop-in diff to add the field to the Census form
- `docs/patches/censuses_controller_permit_category.diff` — permit `:category_id`
- `lib/tasks/categories_upgrade.rake` — helper to collapse existing many-to-many data into the single field
- `docs/seeds_append_categories.rb` — snippet to seed a few categories and attach them

## Steps
1. Copy files into your app.
2. `bin/rails db:migrate`
3. Patch your forms/controllers to permit `:category_id` (use the diffs as guides).
4. (Optional) If you previously used many-to-many categories:
   ```bash
   bin/rails categories:collapse_to_single
   ```
5. (Optional) Append the seed snippet and run `bin/rails db:seed`.

## Notes
- Keep `Categorizable` removed/unused; this approach uses a single FK.
- You can add `belongs_to :category, optional: true` to each model where you want categories.
