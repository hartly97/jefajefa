class Category < ApplicationRecord
  include Sluggable if defined?(Sluggable)

  validates :name, presence: true, uniqueness: { case_sensitive: false }

  # One-to-many relationships (each record has ONE category)
  # Add/remove lines for the models you care about.
  has_many :sources,          dependent: :nullify
  has_many :censuses,         dependent: :nullify
  has_many :soldiers,         dependent: :nullify
  has_many :cemeteries,       dependent: :nullify
  has_many :articles,         dependent: :nullify
  has_many :people,           dependent: :nullify
  has_many :persons,          dependent: :nullify
  has_many :census_entries,   dependent: :nullify
end
