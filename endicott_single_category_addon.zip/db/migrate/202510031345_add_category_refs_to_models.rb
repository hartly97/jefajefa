class AddCategoryRefsToModels < ActiveRecord::Migration[7.1]
  TABLES = %i[
    sources
    censuses
    soldiers
    cemeteries
    articles
    people
    persons
    census_entries
  ]

  def up
    TABLES.each do |table|
      next unless table_exists?(table)
      unless column_exists?(table, :category_id)
        add_reference table, :category, foreign_key: true, index: true
      end
    end
  end

  def down
    TABLES.each do |table|
      next unless table_exists?(table)
      if column_exists?(table, :category_id)
        remove_reference table, :category, foreign_key: true
      end
    end
  end
end
