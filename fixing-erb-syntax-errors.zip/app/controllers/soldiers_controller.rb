# app/controllers/soldiers_controller.rb
class SoldiersController < ApplicationController
  before_action :set_soldier,  only: %i[show edit update destroy regenerate_slug]
  before_action :load_sources, only: %i[new edit]
  before_action :build_nested_rows, only: %i[new edit]

  def index
    @q = params[:q].to_s.strip
    scope = Soldier.includes(:categories).order(:last_name, :first_name)
    scope = scope.search_name(@q) if @q.present?

    @total_count = scope.count
    @total_pages = (@total_count.to_f / page_size).ceil
    offset = (current_page - 1) * page_size

    @soldiers = scope.limit(page_size).offset(offset)
    @has_next  = current_page < @total_pages
  end

  def show
    ActiveRecord::Associations::Preloader.new(
      records: [@soldier],
      associations: [
        :cemetery,
        :awards,
        :categories,
        { citations: :source },
        { involvements: :involvable }
      ]
    ).call
  end

  def new
    @soldier ||= Soldier.new
  end

  def edit; end

  def create
    @soldier = Soldier.new(soldier_params)
    if @soldier.save
      redirect_to @soldier, notice: "Soldier created."
    else
      load_sources
      build_nested_rows
      render :new, status: :unprocessable_entity
    end
  end

  def update
    if @soldier.update(soldier_params)
      redirect_to @soldier, notice: "Soldier updated."
    else
      load_sources
      build_nested_rows
      render :edit, status: :unprocessable_entity
    end
  end

  def destroy
    @soldier.destroy
    redirect_to soldiers_path, notice: "Soldier deleted."
  end

  def regenerate_slug
    @soldier.regenerate_slug!
    redirect_to @soldier, notice: "Slug regenerated."
  end

  private

  def set_soldier
    @soldier = Soldier.find_by(slug: params[:id]) || Soldier.find(params[:id])
  end

  def load_sources
    @sources = Source.order(:title)
  end

  def build_nested_rows
    @soldier ||= Soldier.new
    @soldier.awards.build           if @soldier.awards.empty?
    @soldier.soldier_medals.build   if @soldier.soldier_medals.empty?
    @soldier.involvements.build     if @soldier.involvements.empty?
    @soldier.citations.build        if @soldier.citations.empty?
  end

  def page_size
    (params[:per_page].presence || 30).to_i.clamp(1, 200)
  end

  def current_page
    (params[:page].presence || 1).to_i.clamp(1, 10_000)
  end

  def soldier_params
    params.require(:soldier).permit(
      :first_name, :middle_name, :last_name,
      :birth_date, :birthcity, :birthstate, :birthcountry,
      :death_date, :deathcity, :deathstate, :deathcountry, :deathplace,
      :cemetery_id, :unit, :branch_of_service,
      { category_ids: [] },
      awards_attributes: [:id, :name, :country, :year, :note, :_destroy],
      soldier_medals_attributes: [:id, :medal_id, :year, :note, :_destroy],
      involvements_attributes: [:id, :involvable_type, :involvable_id, :role, :year, :note, :_destroy],
      citations_attributes: [
        :id, :source_id, :_destroy,
        :page, :pages, :folio, :column, :line_number, :record_number, :locator,
        :image_url, :image_frame, :roll, :enumeration_district, :quote, :note,
        { source_attributes: [:id, :title, :author, :publisher, :year, :url, :details, :repository, :link_url] }
      ]
    )
  end
end
