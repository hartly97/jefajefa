# app/helpers/categories_helper.rb
module CategoriesHelper
  def category_badge_class(cat)
    case cat.category_type.to_s
    when "war"      then "text-bg-primary"
    when "battle"   then "text-bg-secondary"
    when "medal"    then "text-bg-success"
    when "award"    then "text-bg-warning"
    when "location" then "text-bg-info"
    when "topic"    then "text-bg-light"
    else                 "text-bg-light"
    end
  end
end
