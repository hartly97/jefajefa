# app/models/concerns/sluggable.rb
require "securerandom"

module Sluggable
  extend ActiveSupport::Concern

  included do
    before_validation :generate_slug, if: :needs_slug?
    validates :slug, presence: true, uniqueness: { case_sensitive: false }
  end

  # Regenerate on demand with same rules
  def regenerate_slug!
    base = (respond_to?(:slug_source, true) ? send(:slug_source) : nil).to_s.parameterize
    base = base.presence || SecureRandom.hex(4)
    candidate = base
    i = 1
    while self.class.unscoped.where(slug: candidate).where.not(id: id).exists?
      i += 1
      candidate = "#{base}-#{i}"
    end
    update(slug: candidate)
  end

  private

  def needs_slug?
    slug.blank? && respond_to?(:slug_source, true)
  end

  def generate_slug
    base = (respond_to?(:slug_source, true) ? send(:slug_source) : nil).to_s.parameterize
    base = base.presence || SecureRandom.hex(4)
    candidate = base
    i = 1
    while self.class.unscoped.where(slug: candidate).where.not(id: id).exists?
      i += 1
      candidate = "#{base}-#{i}"
    end
    self.slug = candidate
  end
end
